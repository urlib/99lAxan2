===============
Sandbox example
===============

Very simple, minimal sandboxing example.

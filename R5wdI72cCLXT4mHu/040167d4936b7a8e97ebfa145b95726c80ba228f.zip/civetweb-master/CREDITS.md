# Civetweb Contributors

* Abhishek Lekshmanan
* Abramo Bagnara
* Adam Bailey
* Alan Somers
* Alberto Bignotti
* Alex Kozlov
* AndreyArsov
* Anton Te
* beaver
* bel2125
* Ben M. Ward
* BigJoe
* Bjoern Petri
* Braedy Kuzma
* Breno Ramalho Lemes
* brett
* Brian Lambert
* Brian Spratke
* cdbishop
* celeron55
* Chris Jones
* Chris Rehn
* Charles Olivi
* Christian Mauderer
* Christopher Galas
* cjh
* Colden Cullen
* Colm Sloan
* Cortronic
* Daniel Oaks
* Daniel Rempel
* Danny Al-Gaaf
* Dave Brower
* daveelton
* David Arnold
* David Loffredo
* Dialga
* Domenico Di Iorio
* duong2179
* ehlertjd
* Eric Tsau
* Erick Vieyra
* Erik Beran
* Erik Partridge
* extergnoto
* Fabrice Fontaine
* feneuilflo
* Fernando G. Aranda
* Frank Hilliger
* F-Secure Corporation
* Grahack
* Gregor Jasny
* grenclave
* grunk
* Guilherme Amadio
* hansipie
* HariKamath Kamath
* Henry Chang
* Herumb Shandilya
* Herve Codina
* Iain Morton
* Ivan Dlugos
* ImgBotApp
* Jack
* Jacob Repp
* Jacob Skillin
* Jan Kowalewski
* Jan Willem Janssen
* Jeremy Lin
* Jim Evans
* jmc-
* Joakim L. Gilje
* Jochen Scheib
* Joel Gallant
* Joe Mucchiello
* Johan De Taeye
* John Faith
* Jordan
* Jordan Shelley
* Joshua Boyd
* Joshua D. Boyd
* k-mds
* kakwa
* kalphamon
* Karol Mroz
* Keith Holman
* Keith Kyzivat
* Ken Walters
* Kevin Branigan
* Kevin Wojniak
* Khem Raj
* Kimmo Mustonen
* Krzysztof Kozlowski
* Lammert Bies
* Lawrence
* Lianghui
* Li Peng
* Luka Rahne
* Maarten Fremouw
* makrsmark
* marco
* Mark Lakata
* Martin Gaida
* Mateusz Gralka
* Matt Clarkson
* Mellnik
* Mike Crowe
* mingodad
* Morgan McGuire
* mrdvlpr.xnu
* Neil Jensen
* newsoft
* nfrmtkr
* Nick Hildebrant
* Nigel Stewart
* nihildeb
* No Face Press
* palortoff
* Patrick Drechsler
* Patrick Trinkle
* Paulo Brizolara
* Paul Sokolovsky
* pavel.pimenov
* PavelVozenilek
* Perttu Ahola
* Peter Foerster
* Philipp Friedenberger
* Philipp Hasper
* pkvamme
* Radoslaw Zarzynski
* Red54
* Retallack Mark mark.retallack
* Richard Screene
* ryankopf
* Sage Weil
* Sangwhan Moon
* Saumitra Vikram
* Scott Nations
* Sebastien Jodogne
* Sergey Linev
* sgmesservey
* shantanugadgil
* Simon Hailes
* slidertom
* SpaceLord
* sunfch
* suzukibitman
* Tamotsu Kanoh
* thewaterymoon
* Thiago Macedo
* THILMANT, Bernard
* Thomas Davis
* Thomas Klausner
* Tomasz Gorochowik
* Thorsten Horstmann
* tnoho
* Tomas Andrle
* Tom Deblauwe
* Toni Wilk
* Torben Jonas
* Uilian Ries
* Ulrich Hertlein
* Walt Steverson
* webxer
* William Greathouse
* xeoshow
* xtne6f
* Yehuda Sadeh
* Yury Z
* zhen.wang

# Mongoose Contributors
CivetWeb is based on the Mongoose code.  The following users contributed to the original Mongoose release between 2010 and 2013.  This list was generated from the Mongoose GIT logs.  It does not contain contributions from the Mongoose mailing list.  There is no record for contributors prior to 2010.

* Sergey Lyubka
* Arnout Vandecappelle (Essensium/Mind)
* Benoît Amiaux
* Cody Hanson
* Colin Leitner
* Daniel Oaks
* Eric Bakan
* Erik Oomen
* Filipp Kovalev
* Ger Hobbelt
* Hendrik Polczynski
* Henrique Mendonça
* Igor Okulist
* Jay
* Joe Mucchiello
* John Safranek
* Joseph Mainwaring
* José Miguel Gonçalves
* KIU Shueng Chuan
* Katerina Blinova
* Konstantin Sorokin
* Marin Atanasov Nikolov
* Matt Healy
* Miguel Morales
* Mikhail Nikalyukin
* MikieMorales
* Mitch Hendrickson
* Nigel Stewart
* Pavel
* Pavel Khlebovich
* Rogerz Zhang
* Sebastian Reinhard
* Stefan Doehla
* Thileepan
* abadc0de
* arvidn
* bick
* ff.feng
* jmucchiello
* jwang
* lsm
* migal
* mlamb
* nullable.type
* shantanugadgil
* tayS
* test
* valenok

